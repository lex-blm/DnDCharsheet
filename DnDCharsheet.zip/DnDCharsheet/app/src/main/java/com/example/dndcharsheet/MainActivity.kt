package com.example.dndcharsheet  // replace with your actual package name

import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import android.content.SharedPreferences

class MainActivity : AppCompatActivity() {

    // Declare your views
    private lateinit var nameEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var inventoryInput: EditText
    private lateinit var addItemButton: Button
    private lateinit var deleteItemButton: Button
    private lateinit var inventoryList: ListView

    // SharedPreferences file name
    private val sharedPreferencesFile = "DnDCharSheetSharedPreferences"

    // Inventory list
    private val inventory = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize your views
        nameEditText = findViewById(R.id.name)
        ageEditText = findViewById(R.id.age)
        inventoryInput = findViewById(R.id.inventory_input)
        addItemButton = findViewById(R.id.add_item_button)
        deleteItemButton = findViewById(R.id.delete_item_button)
        inventoryList = findViewById(R.id.inventory_list)

        // Initialize SharedPreferences
        val sharedPreferences = getSharedPreferences(sharedPreferencesFile, Context.MODE_PRIVATE)

        // Load the saved data (if any) when the app starts
        nameEditText.setText(sharedPreferences.getString("SavedName", ""))
        ageEditText.setText(sharedPreferences.getString("SavedAge", ""))
        loadInventory(sharedPreferences)

        // Update the inventory list
        updateInventoryList()

        // Set the choice mode to single selection
        inventoryList.choiceMode = ListView.CHOICE_MODE_SINGLE

        addItemButton.setOnClickListener {
            // Get the text from inventoryInput
            val newItem = inventoryInput.text.toString()

            // Add the new item to the inventory
            inventory.add(newItem)

            // Clear the inventoryInput
            inventoryInput.setText("")

            // Update the inventoryList and save the updated inventory
            updateInventoryList()
            saveInventory(sharedPreferences)
        }

        deleteItemButton.setOnClickListener {
            // Get the position of the selected item
            val selectedItemPosition = inventoryList.checkedItemPosition

            // If an item is selected, remove it from the inventory
            if (selectedItemPosition != ListView.INVALID_POSITION) {
                inventory.removeAt(selectedItemPosition)
            }

            // Update the inventoryList and save the updated inventory
            updateInventoryList()
            saveInventory(sharedPreferences)
        }
    }

    private fun updateInventoryList() {
        // Create an ArrayAdapter
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, inventory)

        // Set the adapter to the inventoryList
        inventoryList.adapter = adapter
    }

    private fun loadInventory(sharedPreferences: SharedPreferences) {
        // Get the saved inventory string
        val savedInventoryString = sharedPreferences.getString("SavedInventory", "")

        // Split the string into items and add them to the inventory
        savedInventoryString?.split(",")?.forEach { item ->
            if (item.isNotBlank()) {
                inventory.add(item.trim())
            }
        }
    }

    private fun saveInventory(sharedPreferences: SharedPreferences) {
        // Join the inventory items into a comma-separated string
        val inventoryString = inventory.joinToString(",")

        // Save the string to SharedPreferences
        with(sharedPreferences.edit()) {
            putString("SavedInventory", inventoryString)
            apply()
        }
    }
}
